import boto3
import json

"""
Assumming the resource output is passed through the event

{
    "output": ""
}

OR

{
    "output": "alb-dns-output"
}

"""
def handler(event, context):
    s3_resource = boto3.resource("s3")
    S3_BUCKET = 'my-terraform-state-a2b1gnhxyx'
    S3_OBJECT = 'terraform.tfstate'
    
    object = s3_resource.Object(S3_BUCKET, S3_OBJECT)
    file = object.get()['Body'].read().decode('utf-8')
    json_content = json.loads(file)
    
    # all outputs stored in state file
    state_outputs = json_content["outputs"]
    
    # optional specific resource output
    resource_output = event["output"]

    if not resource_output:
        for res in state_outputs:
            print(state_outputs[res]["value"])
    else:
        print(state_outputs[resource_output]["value"])